
const User = require("../models/user");


const addUser = async (req, res, next) => {
  console.log("write ur functionality here")
 
}

exports.addUser = addUser;
